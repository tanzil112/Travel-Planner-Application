package com.example.demo.service;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import org.json.JSONObject;

import java.util.Base64;
import java.util.Optional;
import java.util.regex.Pattern;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;  // Used for password encryption

    // Regular Expression for password validation
    private static final String PASSWORD_PATTERN = "^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[@#$%^&+=]).{8,}$";

    @Value("${razorpay.api.key}")
    private String key;

    @Value("${razorpay.api.secret}")
    private String secret;

    public String register(User user, String confirmPassword) {
        // Validate password using regex
        if (!Pattern.matches(PASSWORD_PATTERN, user.getPassword())) {
            return "Password must be alphanumeric and include at least one special character.";
        }

        // Validate confirmPassword
        if (!user.getPassword().equals(confirmPassword)) {
            return "Passwords do not match.";
        }

        // Check if email is already registered
        if (userRepository.findByUsername(user.getUsername()).isPresent()) {
            return "Email is already registered.";
        }

        // Encrypt password before saving to database
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        userRepository.save(user);
        return "User registered successfully!";
    }

    public Optional<User> login(String email, String password) {
        // Fetch user by username (email) and check if password matches
        Optional<User> userOptional = userRepository.findByUsername(email);
        return userOptional.filter(user -> passwordEncoder.matches(password, user.getPassword())); // Check encrypted password
    }

    public String createOrder(int amount, String currency, String receipt) throws RazorpayException {
        // Razorpay client initialization with API key and secret
        RazorpayClient razorpay = new RazorpayClient(key, secret);

        // Create the order request
        JSONObject orderRequest = new JSONObject();
        orderRequest.put("amount", amount * 100); // Amount in paise (1 INR = 100 paise)
        orderRequest.put("currency", currency);
        orderRequest.put("receipt", receipt);

        // Create and return the order
        Order order = razorpay.orders.create(orderRequest);
        return order.toString();  // Return the order as a JSON string
    }

    public boolean verifyPayment(String orderId, String paymentId, String signature) {
        // Generate HMAC SHA256 signature for payment verification
        String generatedSignature = HmacSHA256(orderId + "|" + paymentId, secret);
        return generatedSignature.equals(signature);  // Return true if the signature matches
    }

    private String HmacSHA256(String data, String secret) {
        try {
            javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");
            mac.init(new javax.crypto.spec.SecretKeySpec(secret.getBytes(), "HmacSHA256"));
            byte[] hmacData = mac.doFinal(data.getBytes());
            return Base64.getEncoder().encodeToString(hmacData);  // Return the Base64 encoded HMAC signature
        } catch (Exception e) {
            throw new RuntimeException("Failed to calculate HMAC SHA256", e);
        }
    }
}
