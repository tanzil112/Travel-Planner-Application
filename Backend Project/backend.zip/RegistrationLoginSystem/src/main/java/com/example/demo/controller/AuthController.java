package com.example.demo.controller;

import com.example.demo.model.Flights;
import com.example.demo.model.Suggestion;
import com.example.demo.model.TravelInfo;
import com.example.demo.model.User;
import com.example.demo.service.FlightService;  // Add the appropriate service for flights
import com.example.demo.service.SuggestionService;  // Separate service for suggestions
import com.example.demo.service.TravelInfoService;  // Separate service for travel info
import com.example.demo.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:5173")
public class AuthController {

    // AuthController functionalities
    @Autowired
    private UserService userService;

    // Use separate services for travel management
    @Autowired
    private SuggestionService suggestionService;

    @Autowired
    private TravelInfoService travelInfoService;

    // Use a separate service for flight-related functionalities
    @Autowired
    private FlightService flightService;

    // Authentication and User Management
    @PostMapping("/auth/register")
    public String registerUser(@RequestBody User user, @RequestParam String confirmPassword) {
        return userService.register(user, confirmPassword);
    }

    @PostMapping("/auth/login")
    public String loginUser(@RequestBody User user) {
        if (user.getUsername() == null || user.getUsername().isEmpty() ||
            user.getPassword() == null || user.getPassword().isEmpty()) {
            return "Username and password cannot be empty";
        }

        Optional<User> existingUser = userService.login(user.getUsername(), user.getPassword());
        return existingUser.isPresent() ? "Login successful!" : "Invalid username or password";
    }

    @GetMapping("/auth/flights")
    public List<Flights> searchFlights(
            @RequestParam String departureCity,
            @RequestParam String arrivalCity,
            @RequestParam String travelDate) {
        return flightService.searchFlights(departureCity, arrivalCity, travelDate);  // Use the flight service here
    }

    @GetMapping("/auth/all-flights")
    public List<Flights> getAllFlights() {
        return flightService.getAllFlights();  // Corrected to call flight service
    }

    @PostMapping("/auth/booking")
    public String bookFlight(@RequestParam Long flightId, @RequestParam int passengers) {
        try {
            return flightService.bookFlight(flightId, passengers);  // Use the flight service for booking
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    // Travel Management
    @GetMapping("/travel/suggestions")
    public List<Suggestion> getSuggestions(@RequestParam String location) {
        return suggestionService.getSuggestionsByLocation(location);
    }

    @GetMapping("/travel/info")
    public TravelInfo getTravelInfo(@RequestParam String destination) {
        return travelInfoService.getTravelInfoByDestination(destination);
    }
}
